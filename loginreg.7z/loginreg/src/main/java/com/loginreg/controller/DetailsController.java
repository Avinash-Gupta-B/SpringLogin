package com.loginreg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.loginreg.service.*;

@Controller
@Configuration
@ComponentScan("com.loginreg.service")
public class DetailsController {
	
	@Autowired
	public LoginService loginService;

	@RequestMapping(value="/", method=RequestMethod.GET)
	public String home(){
		System.out.println("This is a home page");
		boolean userExists = loginService.checkLoginService("deepak",
                "deepak");
		if(userExists){
			System.out.println("User exists");
		}else{
			System.out.println("User not exists");
		}
		return "home";
	}
	
	@RequestMapping(value="/welcome", method=RequestMethod.GET)
	public String welcome(Model m){
			m.addAttribute("name", "Avinash");
		return "welcome";
	}
}

package com.loginreg.dao;

import com.loginreg.model.*;

public interface LoginDAO {
	public boolean login(String username, String userpassword);
}

package com.loginreg.service;

import com.loginreg.model.*;

public interface LoginService {
	public boolean checkLoginService(String username, String userpassword);
}

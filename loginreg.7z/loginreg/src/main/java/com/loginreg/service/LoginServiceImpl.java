package com.loginreg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loginreg.dao.*;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDAO dao;

	public void setLoginDAO(LoginDAO dao) {
		this.dao = dao;
	}

	public boolean checkLoginService(String username, String userpassword) {

		return dao.login(username, userpassword);
	}

}
